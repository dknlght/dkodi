#India4movie for XBMC/Kodi

Quick and dirty addon to scrape [India4movie](http://www.india4movie.com/) for movies.

**Still needs lots of work. Not fully tested.**


##Dependencies

The addon relies on the following addons to resolve/play videos

 - [Url Resolver](http://wiki.xbmc.org/index.php?title=Add-on:Urlresolver)
 - [YouTube](http://wiki.xbmc.org/index.php?title=Add-on:YouTube)
